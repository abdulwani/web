<?php


$subjects = array("Math", "Physics", "CS");

echo "Subjects:<br>";
print_r($subjects);

$grid = array(
    array(1,2),
    array(3,4)
);

echo "<br><br>2D Array:<br>";
print_r($grid);

?>
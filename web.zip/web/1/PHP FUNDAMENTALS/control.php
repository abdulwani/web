<?php

$marks = 75;

if ($marks >= 40) {
    echo "Pass<br>";
}


if ($marks >= 40) {
    echo "Passed<br>";
} else {
    echo "Failed<br>";
}

if ($marks >= 80) {
    echo "Grade A<br>";
}
elseif ($marks >= 60) {
    echo "Grade B<br>";
}
else {
    echo "Grade C<br>";
}

$grade = "B";

switch ($grade) {
    case "A":
        echo "Excellent<br>";
        break;

    case "B":
        echo "Good<br>";
        break;

    default:
        echo "Average<br>";
}

$i = 1;
while ($i <= 3) {
    echo $i . "<br>";
    $i++;
}

$i = 1;
do {
    echo $i . "<br>";
    $i++;
} while ($i <= 3);


for ($i = 1; $i <= 3; $i++) {
    echo $i . "<br>";
}

$subjects = array("Math", "Physics", "CS");

foreach ($subjects as $s) {
    echo $s . "<br>";
}

?>
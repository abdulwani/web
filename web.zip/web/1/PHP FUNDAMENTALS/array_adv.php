<?php

$a = array("Apple", "Mango", "Banana");

$b = array(
    "Name" => "Amaan",
    "Age" => 20
);

$c = array(
    array(1,2),
    array(3,4)
);

print_r($a);

echo "<br><br>";

print_r($b);

echo "<br><br>";

print_r($c);


echo "<br><br>Total: ";
echo count($a);


sort($a);

echo "<br><br>Sorted Array:<br>";
print_r($a);


$x = array("A", "B");
$y = array("C", "D");

$z = array_merge($x, $y);

echo "<br><br>Merged Array:<br>";
print_r($z);

?>
<?php

$name = "Amaan";
$_name = "Student";
$name1 = "PHP";

define("SITE_NAME", "CUK");

echo SITE_NAME;
echo "<br>";

$a = "Hello";       
$b = 10;            
$c = 10.5;         
$d = true;         
$e = array(1,2,3);  
$f = NULL;         

echo $a;echo "<br>";

echo $b;echo "<br>";

echo $c;echo "<br>";

echo $d;echo "<br>";

print_r($e);
echo "<br>";
var_dump($f);
?>
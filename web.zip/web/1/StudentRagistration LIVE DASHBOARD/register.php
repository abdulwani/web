<?php
define("SITE", "CUK");
$subjects = array("HTML", "PHP", "JavaScript");
print_r($subjects);

$grid = array(
    array(1,2),
    array(3,4)
);

print_r($grid);

$conn = new mysqli("localhost", "root", "", "college");

if ($conn->connect_error) {
    die("Connection failed");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $gender = $_POST["gender"];
    $course = $_POST["course"];

    // If else
    if ($name == "") {
        echo "Name required";
    }
    else {

        switch ($course) {
            case "BCA":
                $msg = "BCA Selected";
                break;

            case "CSE":
                $msg = "CSE Selected";
                break;

            case "MCA":
                $msg = "MCA Selected";
                break;
        }

        echo $msg;

        $stmt = $conn->prepare(
            "INSERT INTO student(name,gender,course) VALUES(?,?,?)"
        );

        $stmt->bind_param("sss", $name, $gender, $course);
        $stmt->execute();
        echo "<h3>Registration Successful</h3>";
        $stmt->close();
    }
}

$result = $conn->query("SELECT * FROM student");

echo "<h2>Student Records</h2>";

echo "<table border='1'>
<tr>
<th>ID</th>
<th>Name</th>
<th>Gender</th>
<th>Course</th>
</tr>";

while ($row = $result->fetch_assoc()) {

    echo "<tr>";
    echo "<td>".$row['id']."</td>";
    echo "<td>".$row['name']."</td>";
    echo "<td>".$row['gender']."</td>";
    echo "<td>".$row['course']."</td>";
    echo "</tr>";

}
echo "</table>";
echo "<a href='dashboard.php'>Dashboard</a>";
$conn->close();

?>
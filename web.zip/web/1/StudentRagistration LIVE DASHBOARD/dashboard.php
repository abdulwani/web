<?php

$conn = new mysqli("localhost", "root", "", "college");

if ($conn->connect_error) {
    die("Connection failed");
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    if (filter_var($id, FILTER_VALIDATE_INT) && $id > 0) {

        $stmt = $conn->prepare("DELETE FROM student WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: dashboard.php");
    exit;
}

$result = $conn->query("SELECT * FROM student");

echo "<h2>Student Dashboard</h2>";
echo "Total Students: " . $result->num_rows;
echo "<table border='1'>
<tr>
<th>ID</th>
<th>Name</th>
<th>Gender</th>
<th>Course</th>
<th>Delete</th>
</tr>";

while ($row = $result->fetch_assoc()) {

    echo "<tr>";
    echo "<td>".$row['id']."</td>";
    echo "<td>".htmlspecialchars($row['name'])."</td>";
    echo "<td>".htmlspecialchars($row['gender'])."</td>";
    echo "<td>".htmlspecialchars($row['course'])."</td>";

    echo "<td><a href='dashboard.php?delete=".$row['id']."'>Delete</a></td>";
    echo "</tr>";
}
echo "</table>";
$conn->close();
?>
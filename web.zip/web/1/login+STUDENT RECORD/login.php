<?php

session_start();

define("SITE", "CUK");

$conn = new mysqli("localhost", "root", "", "portal");

if ($conn->connect_error) {
    die("Connection failed");
}

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$stmt = $conn->prepare("SELECT * FROM users WHERE username=?");

$stmt->bind_param("s", $username);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {

    if (password_verify($password, $row['password_hash'])
        && $role == $row['role']) {

        $_SESSION['username'] = $username;

        header("Location: records.php");
        exit;

    } else {
        echo "Wrong password or role";
    }

} else {
    echo "User not found";
}

$stmt->close();
$conn->close();

?>
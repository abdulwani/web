<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "portal");

if (isset($_POST['update'])) {

    $id = $_POST['id'];
    $marks = $_POST['marks'];

    $stmt = $conn->prepare("UPDATE student SET marks=? WHERE id=?");
    $stmt->bind_param("ii", $marks, $id);
    $stmt->execute();
    $stmt->close();
}

if (isset($_GET['delete'])) {

    $id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM student WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: records.php");
    exit;
}

$result = $conn->query("SELECT * FROM student");

?>

<h2>Student Records</h2>

<p>Welcome <?php echo $_SESSION['username']; ?></p>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Name</th>
<th>Course</th>
<th>Marks</th>
<th>Update</th>
<th>Delete</th>
</tr>

<?php

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['course']; ?></td>
<td><?php echo $row['marks']; ?></td>

<td>
<form method="post">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<input type="number" name="marks" placeholder="New marks">
<button name="update">Update</button>
</form>
</td>

<td>
<a href="records.php?delete=<?php echo $row['id']; ?>">Delete</a>
</td>

</tr>
<?php
}
?>

</table>
<?php
$conn->close();
?>
CREATE DATABASE portal;

USE portal;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password_hash VARCHAR(255),
    role VARCHAR(20)
);

CREATE TABLE student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    course VARCHAR(30),
    marks INT
);

INSERT INTO users(username,password_hash,role)
VALUES('admin',
'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi',
'Admin');

INSERT INTO student(name,course,marks)
VALUES('Amaan','BCA',85);

INSERT INTO student(name,course,marks)
VALUES('amaan','MCA',75);
SELECT * FROM student;

UPDATE student SET marks=90 WHERE id=1;

DELETE FROM student WHERE id=2;


<?php
define("SITE", "CUK");

// Six data types
$s = "Hello";       // String
$i = 10;            // Integer
$f = 10.5;          // Float
$b = true;          // Boolean
$a = [1,2,3];       // Array
$n = NULL;          // NULL

// Arrays
$subjects = ["Math", "Physics", "CS"];
$grid = [[1,2], [3,4]];

print_r($subjects);
print_r($grid);

$msg = "";

$conn = new mysqli("localhost", "root", "", "college");

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $course = $_POST['course'];

    if(empty($name)){
        $msg = "Name required";
    }
    else{
        switch($gender){
            case "Male": $msg = "Male student"; break;
            case "Female": $msg = "Female student"; break;
            default: $msg = "Invalid gender";
        }

        if($gender == "Male" || $gender == "Female"){

            // Prepared statements prevent SQL Injection.
            $stmt = $conn->prepare("INSERT INTO student(name,gender,course) VALUES(?,?,?)");

            $stmt->bind_param("sss", $name, $gender, $course);
            $stmt->execute();

            $msg = "Registration successful";
        }
    }
}

echo "<h3>$msg</h3>";

// Display records
$res = $conn->query("SELECT * FROM student");

echo "<table border='1'><tr><th>ID</th><th>Name</th><th>Gender</th><th>Course</th></tr>";

foreach($res as $row){
    echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['name']}</td>
    <td>{$row['gender']}</td>
    <td>{$row['course']}</td>
    </tr>";
}

echo "</table>";
?>
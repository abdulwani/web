<?php
$conn = new mysqli("localhost", "root", "", "college");

// Delete record using validated ID and prepared statement
if(isset($_GET['del'])){

    $id = filter_var($_GET['del'], FILTER_VALIDATE_INT);

    if($id !== false && $id > 0){
        $stmt = $conn->prepare("DELETE FROM student WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

$res = $conn->query("SELECT * FROM student");

echo "Total Students: " . $res->num_rows;

echo "<table border='1'>
<tr><th>ID</th><th>Name</th><th>Course</th><th>Action</th></tr>";

while($row = $res->fetch_assoc()){

    echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['name']}</td>
    <td>{$row['course']}</td>
    <td><a href='?del={$row['id']}'>Delete</a></td>
    </tr>";
}

echo "</table>";
?>
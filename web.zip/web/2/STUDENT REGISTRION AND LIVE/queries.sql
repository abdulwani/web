CREATE DATABASE college;
USE college;

CREATE TABLE student(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(50),
gender VARCHAR(10),
course VARCHAR(30),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO student(name,gender,course)
VALUES('John','Male','Math');

SELECT * FROM student;

UPDATE student SET course='CSE' WHERE id=1;
SELECT ROW_COUNT();

DELETE FROM student WHERE id=2;
SELECT ROW_COUNT();
<?php
// Start session and set cookie lifetime for Remember Me.
$remember = isset($_POST['remember']);

session_set_cookie_params([
    'lifetime' => $remember ? 86400 : 0,
    'path' => '/'
]);

session_start();

define("SITE", "PORTAL");

// Six data types
$s = "Hello";
$i = 10;
$f = 10.5;
$b = true;
$a = [1,2,3];
$n = NULL;

// Arrays
$subjects = ["Math", "CS", "Physics"];
$grid = [[1,2], [3,4]];

print_r($subjects);
print_r($grid);

$conn = new mysqli("localhost", "root", "", "portal");

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepared statement prevents SQL Injection.
    // Example attack: ' OR '1'='1
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $user = $stmt->get_result()->fetch_assoc();

    if($user && password_verify($password, $user['password_hash'])){

        $_SESSION['role'] = $user['role'];
        $_SESSION['username'] = $username;

        header("Location: records.php");
        exit();
    }
    else{
        echo "Invalid username or password";
    }
}
?>
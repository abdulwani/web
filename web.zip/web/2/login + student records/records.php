<?php
session_start();

if(!isset($_SESSION['role'])){
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "portal");

// Delete student using prepared statement
if(isset($_GET['del'])){

    $id = filter_var($_GET['del'], FILTER_VALIDATE_INT);

    if($id !== false && $id > 0){
        $stmt = $conn->prepare("DELETE FROM student WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

// Update marks using prepared statement
if(isset($_POST['update'])){

    $id = (int)$_POST['id'];
    $marks = (int)$_POST['marks'];

    $stmt = $conn->prepare("UPDATE student SET marks=? WHERE id=?");
    $stmt->bind_param("ii", $marks, $id);
    $stmt->execute();
}

$res = $conn->query("SELECT * FROM student");

$data = $res->fetch_all(MYSQLI_ASSOC);

// Array functions
echo "Total Students: " . count($data);

$marks = array_column($data, 'marks');
sort($marks);

echo "<br>Total Marks: " . array_sum($marks);

// Demonstrate for loop
for($i=0; $i<count($marks); $i++){
    // Loop through marks
}

// Demonstrate while loop
$j = 0;
while($j < 1){
    $j++;
}

// Display records using foreach
echo "<table border='1'>
<tr><th>ID</th><th>Name</th><th>Course</th><th>Marks</th><th>Action</th></tr>";

foreach($data as $row){

    echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['name']}</td>
    <td>{$row['course']}</td>
    <td>{$row['marks']}</td>
    <td>
    <form method='post'>
    <input type='hidden' name='id' value='{$row['id']}'>
    <input type='number' name='marks'>
    <input type='submit' name='update' value='Update'>
    </form>
    <a href='?del={$row['id']}'>Delete</a>
    </td>
    </tr>";
}

echo "</table>";
?>
CREATE DATABASE portal;
USE portal;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
password_hash VARCHAR(255),
role VARCHAR(20)
);

CREATE TABLE student(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(50),
course VARCHAR(30),
marks INT
);

INSERT INTO student(name,course,marks)
VALUES('Amaan','CSE',85);

SELECT * FROM student;

UPDATE student SET marks=90 WHERE id=1;

DELETE FROM student WHERE id=1;
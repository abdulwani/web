<?php

$subjects = array("Math", "Physics", "CS");


$grid = array(array(1,2), array(3,4));

echo "Subjects:";
print_r($subjects);

echo "<br>Grid:";
print_r($grid);

echo "<br>First Subject: " . $subjects[0];

?>
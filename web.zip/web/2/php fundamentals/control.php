<?php

$marks = 85;

// if
if($marks > 40){
    echo "Pass<br>";
}

// if...else
if($marks >= 50){
    echo "Good<br>";
}
else{
    echo "Average<br>";
}

// elseif
if($marks >= 90){
    echo "Grade A";
}
elseif($marks >= 80){
    echo "Grade B";
}
else{
    echo "Grade C";
}

// switch
switch($marks){
    case 85: echo "<br>Excellent"; break;
    default: echo "<br>Normal";
}

// while loop
$i = 1;
while($i <= 3){
    echo "<br>$i";
    $i++;
}

// do...while
$i = 1;
do{
    echo "<br>$i";
    $i++;
}while($i <= 3);

// for loop
for($i=1; $i<=3; $i++){
    echo "<br>$i";
}

// foreach loop
$subjects = ["Math", "Physics", "CS"];

foreach($subjects as $s){
    echo "<br>$s";
}

?>
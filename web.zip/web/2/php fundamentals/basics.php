<?php

$name = "John";
$_name = "Hello";
$name1 = "Student";


define("SITE_NAME", "CUK");

echo SITE_NAME;


$str = "Hello";       // String
$int = 10;            // Integer
$float = 10.5;        // Float
$bool = true;         // Boolean
$arr = [1,2,3];       // Array
$nul = NULL;          // NULL

?>